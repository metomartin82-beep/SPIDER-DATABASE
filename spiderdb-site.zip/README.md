# SpiderDB — Marketing & Docs Site (Phase 1)

This is the **landing page + docs site** for SpiderDB — a branded platform for
giving every user/tenant in an app its own isolated database, built on top of
a real database provider's API under the hood (see the architecture note
below). This phase is intentionally frontend-only: there is no backend yet.

## What's here

```
/
├── index.html                      Landing page
├── pricing.html                    Pricing tiers + comparison table + FAQ
├── blog.html                       Blog listing
├── contact.html                    Contact form (not wired to a backend yet)
├── blog/
│   └── why-isolated-databases.html Example full blog post
├── docs/
│   ├── index.html                  Getting Started, concepts, auth, guides
│   ├── api-reference.html          REST Platform API reference
│   └── cli.html                    CLI command reference
└── assets/
    ├── css/style.css               Full design system (colors, type, components)
    └── js/main.js                  Mobile nav, scroll reveal, hero web diagram, code tabs
```

Every internal link uses root-relative paths (`/pricing.html`, `/docs/index.html`,
etc.), so this deploys correctly as long as it's served from the domain root —
static hosting (Cloud Storage + Cloud CDN, Firebase Hosting) or behind a simple
Express static server both work without changing any paths.

## Design system

Defined as CSS custom properties at the top of `style.css`:

- **Colors**: ink background (`#0D0F14`), spun-silk gold accent (`#E7B24D`),
  garnet/moss as secondary accents, warm paper-white text. Deliberately
  different from SpiderHub's cyan/blue palette — distinct product, distinct identity.
- **Type**: Space Grotesk (headlines) + Inter (body) + JetBrains Mono (code,
  stats, labels) — loaded from Google Fonts via `@import` in `style.css`.
- **Signature visual**: the hero's animated SVG "web diagram" (built in
  `main.js` → `buildWebDiagram()`) — a center node radiating threads out to
  named database nodes, directly illustrating "one database per user."

## What's real vs. placeholder right now

**Real:** all copy, all pricing figures (as *proposed* tiers — sanity-check
against actual wholesale costs before launch), all docs content describes the
actual intended architecture.

**Not yet wired up:**
- "Sign in" / "Get Started" buttons don't link anywhere yet — no auth exists.
- The contact form doesn't submit anywhere — needs a backend endpoint.
- Every code sample (CLI commands, API requests) describes the **planned**
  interface — none of it runs yet. This is Phase 1 (marketing site) of the
  build; the engine (auth, dashboard, database provisioning) is Phase 2.

## Architecture note (for when Phase 2 starts)

Per our discussion: SpiderDB's dashboard, auth, billing, API, and CLI are all
genuinely custom-built. Under the hood, when a user clicks "Create Database,"
the plan is to call a real database provider's platform API (e.g., Turso's,
which explicitly supports this via their Partner Program) to provision an
actual isolated database — not a simulation. The databases created this way
are fully real and functional; SpiderDB is the branded control plane in front
of them, not a reimplementation of the underlying storage engine.

## Suggested next phase

Auth (email/password + Google + GitHub) → dashboard shell → database
create/list/delete wired to the real provider API → API key management →
connection string display. Same iterative approach used for SpiderHub:
build one real, working slice at a time rather than all features at once.
